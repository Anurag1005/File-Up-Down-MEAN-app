const mongoose = require('mongoose');

var file = mongoose.Model('file',{
    file: { type: Buffer, required: true },
    filename: { type: String, required: true },
    mimetype: { type: String, required: true }
    });

    module.exports = file;