const express = require('express');
const bodyParser = require('body-parser');
const mongodb = require('mongodb');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();

//middleware for body parser

app.use(bodyParser.urlencoded({extended : true}));
app.use(cors({ origin: 'http://localhost:4200'}));

// Multer library
var storage = multer.diskStorage({

        destination: function(req,file,cb){
            cb(null,'uploads')
        },
        filename: function(req,file,cb){
            cb(null,file.fieldname+'-'+Date.now() + path.extname(file.originalname));
        }
    })

var upload = multer({storage:storage});

//Routes
app.get('/',(req, res) => {
    res.sendFile(__dirname+'/index.html');
})

// configure Database
const MongoClient = mongodb.MongoClient;

const url = 'mongodb://localhost:27017/FileUD';

MongoClient.connect(url,{
    useUnifiedTopology: true, useNewUrlParser: true},
    (err,client) => {
        if(err) return console.log(err);

        db = client.db('FileUD')

    app.listen(3000,() => {
        console.log("mongo client connected at 3000")
    })
})

var Database = mongodb.connect(url,(err) => {
    if(!err) return console.log("Database is connected at 27017....");
})

// to database
app.post("/uploadphoto",upload.single('myImage'),(req,res) =>{
    var img = fs.readFileSync(req.file.path);
    var encode_image = img.toString('base64');

    // define as JSON object Image 

    var finalimg = {
        contentType : req.file.mimetype,
        path :  req.file.path,
        image : new Buffer(encode_image,'base64')
    };

    // inser in Database

    db.collection('image').insertOne(finalimg,(err, result) => {
        if(err) return console.log(err);

        console.log("saved to database");

        res.contentType(finalimg.contentType);

        res.send(finalimg.image);
    } )
})


app.listen(5000,() => {console.log("Server Listening at 5000...")})