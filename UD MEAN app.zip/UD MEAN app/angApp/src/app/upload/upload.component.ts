import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})

export class UploadComponent implements OnInit {

  selectedFile = null;
  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  onSelect(event) {
    console.log(event);
    this.selectedFile = event.target.files[0];
  }

  onUpload() {
    const fd = new FormData();
    fd.append('file', this.selectedFile, this.selectedFile.name);
    this.http.post('http://localhost:5000/uploadphoto', this.selectedFile)
      .subscribe(res => {
        console.log(res);
      });

  }
}
